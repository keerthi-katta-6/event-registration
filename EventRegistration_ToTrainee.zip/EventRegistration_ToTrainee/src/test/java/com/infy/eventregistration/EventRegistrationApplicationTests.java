package com.infy.eventregistration;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.eventregistration.dto.EventDTO;
import com.infy.eventregistration.dto.ParticipantDTO;
import com.infy.eventregistration.entity.Event;
import com.infy.eventregistration.entity.Participant;
import com.infy.eventregistration.exception.EventRegistrationException;
import com.infy.eventregistration.repository.EventRepository;
import com.infy.eventregistration.repository.ParticipantRepository;
import com.infy.eventregistration.service.EventService;
import com.infy.eventregistration.service.EventServiceImpl;


@SpringBootTest
public class EventRegistrationApplicationTests
{
	@Mock
    private EventRepository eventRepository;

	@Mock
    private ParticipantRepository participantRepository;

	@InjectMocks
    private EventService eventService = new EventServiceImpl();

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
    public void getParticipantsByEventVenueNoParticipantsFoundTest()
    {
	// your code goes here
		String name = "A6-Hall";
		List<Participant> part = new ArrayList<>();
		Mockito.when(participantRepository.findByEventVenue(Mockito.anyString())).thenReturn(part);
		EventRegistrationException e = Assertions.assertThrows(EventRegistrationException.class, 
				()-> eventService.getParticipantsByEventVenue(name));
		Assertions.assertEquals("Service.PARTICIPANTS_UNAVAILABLE", e.getMessage());
    }

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@Test
    public void registerParticipantNoEventFoundTest()
    {
	// your code goes here
		ParticipantDTO part = new ParticipantDTO();
		part.setEmailId("jenny@infy.com");
		part.setGender("Female");
		part.setName("Jenny");
		part.setRegistrationDate(LocalDate.of(2020, 9, 21));
		
		Event ev = new Event();
		ev.setEventDate(LocalDate.now().plusWeeks(2));
		ev.setEventId(1000);
		ev.setMaxCount(5);
		ev.setName("Dancing");
		ev.setVenue("B5-Hall");

		EventDTO evDTO = new EventDTO();
		evDTO.setEventDate(ev.getEventDate());
		evDTO.setEventId(ev.getEventId());
		evDTO.setMaxCount(ev.getMaxCount());
		evDTO.setName(ev.getName());
		evDTO.setVenue(ev.getVenue());
	
		part.setEventDTO(evDTO);
		
		Mockito.when(eventRepository.findByName(Mockito.anyString())).thenReturn(null);
		EventRegistrationException e = Assertions.assertThrows(EventRegistrationException.class,
				()-> eventService.registerParticipant(part));
		Assertions.assertEquals("Service.EVENT_UNAVAILABLE", e.getMessage());
    }
}
