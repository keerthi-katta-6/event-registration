package com.infy.eventregistration.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.eventregistration.dto.EventDTO;
import com.infy.eventregistration.dto.ParticipantDTO;
import com.infy.eventregistration.entity.Event;
import com.infy.eventregistration.entity.Participant;
import com.infy.eventregistration.exception.EventRegistrationException;
import com.infy.eventregistration.repository.EventRepository;
import com.infy.eventregistration.repository.ParticipantRepository;

@Service(value = "eventService")
@Transactional
public class EventServiceImpl implements EventService
{
	@Autowired
    private EventRepository eventRepository;

	@Autowired
    private ParticipantRepository participantRepository;

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
    @Override
    public Integer registerParticipant(ParticipantDTO participantDTO) throws EventRegistrationException
    {
	// your code goes here
    	Event ev = eventRepository.findByName(participantDTO.getEventDTO().getName());
    	if(ev == null) {
    		throw new EventRegistrationException("Service.EVENT_UNAVAILABLE");
    	}
    	List<Participant> partList = participantRepository.findByEvent(ev);
    	if(partList.size() >= ev.getMaxCount()) {
    		throw new EventRegistrationException("Service.REGISTRATION_CLOSED");
    	}
    	if(participantDTO.getRegistrationDate().isAfter(ev.getEventDate().minusDays(3))) {
    		throw new EventRegistrationException("Service.REGISTRATION_CLOSED");
    	}
    	Participant part = new Participant();
    	part.setEmailId(participantDTO.getEmailId());
    	part.setEvent(ev);
    	part.setGender(participantDTO.getGender());
    	part.setName(participantDTO.getName());
    	part.setRegistrationDate(participantDTO.getRegistrationDate());
    	Participant saved = participantRepository.save(part);
    	return saved.getParticipantId();
    }

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
    @Override
    public List<ParticipantDTO> getParticipantsByEventVenue(String venue) throws EventRegistrationException
    {
	// your code goes here
    	List<Participant> partList = participantRepository.findByEventVenue(venue);
    	if(partList.isEmpty()) {
    		throw new EventRegistrationException("Service.PARTICIPANTS_UNAVAILABLE");
    	}
    	List<ParticipantDTO> partDTOList = new ArrayList<ParticipantDTO>();
    	for(Participant part: partList ) {
    		ParticipantDTO partDTO = new ParticipantDTO();
    		partDTO.setEmailId(part.getEmailId());
    		Event ev = part.getEvent();
    		EventDTO evDTO = new EventDTO();
    		evDTO.setEventDate(ev.getEventDate());
    		evDTO.setEventId(ev.getEventId());
    		evDTO.setMaxCount(ev.getMaxCount());
    		evDTO.setName(ev.getName());
    		evDTO.setVenue(ev.getVenue());
    		partDTO.setEventDTO(evDTO);
    		partDTO.setGender(part.getGender());
    		partDTO.setName(part.getName());
    		partDTO.setParticipantId(part.getParticipantId());
    		partDTO.setRegistrationDate(part.getRegistrationDate());
    		partDTOList.add(partDTO);
    	}
    	return partDTOList;
    }
}
