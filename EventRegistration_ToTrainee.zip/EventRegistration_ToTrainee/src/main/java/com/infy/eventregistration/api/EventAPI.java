package com.infy.eventregistration.api;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.eventregistration.dto.ParticipantDTO;
import com.infy.eventregistration.exception.EventRegistrationException;
import com.infy.eventregistration.service.EventService;

@RestController
@Validated
@RequestMapping(value = "/event-api")
public class EventAPI
{
	@Autowired
    private EventService eventService;
	
	@Autowired
    private Environment environment;

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@PostMapping(value = "/events")
    public ResponseEntity<String> registerParticipant(@Valid @RequestBody ParticipantDTO participantDTO) throws EventRegistrationException
    {
	// your code goes here
		Integer participantId = eventService.registerParticipant(participantDTO);
		return new ResponseEntity<String>(environment.getProperty("API.REGISTRATION_SUCCESS")
				+participantId, HttpStatus.CREATED);
    }

    // DO NOT CHANGE METHOD SIGNATURE AND DELETE/COMMENT METHOD
	@GetMapping(value = "/events/{venue}")
    public ResponseEntity<List<ParticipantDTO>> getParticipantsByEventVenue(@PathVariable 
    		@Pattern(regexp = "[A-Z][0-9]-Hall", message = "{event.venue.invalid}") String venue)
    				throws EventRegistrationException
    {
	// your code goes here
		List<ParticipantDTO> participantDTOList = eventService.getParticipantsByEventVenue(venue);
		return new ResponseEntity<List<ParticipantDTO>>(participantDTOList, HttpStatus.OK);
    }

}
