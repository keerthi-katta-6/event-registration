package com.infy.eventregistration.repository;

import org.springframework.data.repository.CrudRepository;

import com.infy.eventregistration.entity.Event;

public interface EventRepository extends CrudRepository<Event, Integer> {
	// your code goes here
	Event findByName(String name);
}
